<?php

namespace Dotsquares\BannerSlider\Controller\Adminhtml\Banner;

use Dotsquares\BannerSlider\Controller\Adminhtml\AbstractBanner;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;


/**
 * Class Index
 *
 * @package Boolfly\BannerSlider\Controller\Adminhtml\Banner
 */
class Index extends AbstractBanner
{

    /**
     * @return void
     */
    public function execute()
    {
        $this->_initAction()->_addBreadcrumb(__('Content'), __('Content'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Manage Banner'));
        $this->_view->renderLayout();
    }
}
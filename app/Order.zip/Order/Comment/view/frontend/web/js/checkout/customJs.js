define(
    [
        'ko',
        'jquery',
        'uiComponent',
        'mage/url'
    ],
    function (ko, $, Component,url) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Order_Comment/checkout/customCheckbox'
            },
            initObservable: function () {

               
              var self = this;
              this.textValue = ko.observable();
              this.radioValue = ko.observable('1');
              this.rawDate = ko.observable();
              var abc ="";
              var efg ="";
              var sdc ="";

               this.submitForm = ko.observable();
               this.submitFormData = function(data,event){

                abc = this.textValue();
                efg = this.radioValue();
                sdc = this.rawDate();
                var linkUrls  = url.build('module/checkout/saveInQuote');
                    //console.log('easyMan',easyMan);
                     $.ajax({
                        showLoader: true,
                        url: linkUrls,
                        data: {checkVal:abc,orderdate:sdc,ordertime:efg},
                        type: "POST",
                        dataType: 'json'
                    }).done(function (data) {
                        console.log('success');
                    });
                   this.submitForm('');
                }

                

                return this;
            }
        });
    }
);

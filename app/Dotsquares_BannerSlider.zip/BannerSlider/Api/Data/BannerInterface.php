<?php

namespace Dotsquares\BannerSlider\Api\Data;

interface BannerInterface
{

    /**#@+
     * Constants Cache Tag
     */
    const CACHE_TAG = 'bs_bannerslider';

    /**#@+
     * Constants defined for keys of data array
     */
    const BANNER_ID = 'banner_id';

    const TITLE = 'title';

    const STATUS = 'status';

    const BANNER_URL = 'banner_url';

    const CONTENT = 'content';

   

    /**
     * Get Banner Id
     *
     * @return string|null
     * @since 1.0.0
     */
    public function getId();

    /**
     * Get Title
     *
     * @return string|null
     * @since 1.0.0
     */
    public function getTitle();

    /**
     * Set Title
     *
     * @param string $title
     *
     * @return $this
     * @since 1.0.0
     */
    public function setTitle($title);

    /**
     * Get Status
     *
     * @return boolean
     * @since 1.0.0
     */
    public function getStatus();

    /**
     * Set Status
     *
     * @param integer|boolean $status
     *
     * @return $this
     * @since 1.0.0
     */
    public function setStatus($status);

    /**
     * Get Banner Url
     *
     * @return string|null
     * @since 1.0.0
     */
    public function getBannerUrl();

    /**
     * Set Banner Url
     *
     * @param string $url
     *
     * @return $this
     * @since 1.0.0
     */
    public function setBannerUrl($url);

    /**
     * Get Banner Description
     *
     * @return string|null
     * @since 1.0.0
     */
    public function getContent();

    /**
     * Set Description
     *
     * @param string $description
     *
     * @return $this
     * @since 1.0.0
     */
    public function setContent($content);

    /**
     * Get Button Text
     *
     * @return string|null
     * @since 1.0.0
     */
    

    /**
     * Set Align Text
     *
     * @param string $alignText
     *
     * @return $this
     * @since 1.0.0
     */
    public function setAlignText($alignText);
}
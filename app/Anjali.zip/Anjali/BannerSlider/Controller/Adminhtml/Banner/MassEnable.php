<?php


namespace Anjali\BannerSlider\Controller\Adminhtml\Banner;


use Anjali\BannerSlider\Api\Data\BannerInterface;
use Magento\Framework\Exception\CouldNotSaveException;

class MassEnable extends AbstractMassAction
{
    
    protected function processCollection(\Anjali\BannerSlider\Model\ResourceModel\Banner\Collection $collection): void
    {
        $itemsSaved = 0;
        /** @var BannerInterface $item */
        foreach ($collection as $item) {
            try {
                if (!$item->getIsEnabled()) {
                    $item->setIsEnabled(true);
                    $this->bannerRepository->save($item);
                    $itemsSaved++;
                }
            } catch (CouldNotSaveException $e) {
                $this->messageManager->addErrorMessage(__('Error saving %1: %2', $item->getEntityId(), $e->getMessage()));
            }
        }
        $this->messageManager->addSuccessMessage(__('%1 Banner(s) enabled', $itemsSaved));
    }
}
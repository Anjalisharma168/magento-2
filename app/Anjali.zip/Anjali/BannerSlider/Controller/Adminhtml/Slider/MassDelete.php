<?php


namespace Anjali\BannerSlider\Controller\Adminhtml\Slider;


use Anjali\BannerSlider\Api\Data\SliderInterface;
use Magento\Framework\Exception\CouldNotDeleteException;

class MassDelete extends AbstractMassAction
{
    
    protected function processCollection(\Anjali\BannerSlider\Model\ResourceModel\Slider\Collection $collection): void
    {
        $itemsDeleted = 0;
        /** @var SliderInterface $item */
        foreach ($collection as $item) {
            try {
                $this->sliderRepository->delete($item);
                $itemsDeleted++;
            } catch (CouldNotDeleteException $e) {
                $this->messageManager->addErrorMessage(__('Error Deleting %1: %2', $item->getEntityId(), $e->getMessage()));
            }
        }
        $this->messageManager->addSuccessMessage(__('%1 Slider(s) deleted', $itemsDeleted));
    }
}
<?php

namespace Dotsquares\BannerSlider\Controller\Adminhtml;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\Filter\Date;
use Dotsquares\BannerSlider\Api\Data\BannerInterfaceFactory;

abstract class AbstractBanner extends Action
{
    
    const ADMIN_RESOURCE = 'Dotsquares_BannerSlider::banner';

    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var BannerInterfaceFactory
     */
    protected $bannerFactory;

    /**
     * AbstractBanner constructor.
     *
     * @param Context                $context
     * @param Registry               $coreRegistry
     * @param BannerInterfaceFactory $bannerFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        BannerInterfaceFactory $bannerFactory
    ) {
        parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->bannerFactory = $bannerFactory;
    }

    /**
     * Init action
     *
     * @return $this
     */
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu(
            'Dotsquares_BannerSlider::manager'
        )->_addBreadcrumb(
            __('Manage Banner'),
            __('Manage Banner')
        );
        return $this;
    }
}
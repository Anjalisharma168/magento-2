<?php

namespace Anjali\BannerSlider\Api\Data;


interface SliderSearchResultInterface extends \Magento\Framework\Api\SearchResultsInterface
{
    /**
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface[]
     */
    public function getItems();

    /**
     * @param \Codilar\BannerSlider\Api\Data\SliderInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
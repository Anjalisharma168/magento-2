<?php

declare(strict_types=1);

namespace Anjali\BannerSlider\Api\Data;


interface SliderInterface
{
    /**
     * @return int
     */
    public function getEntityId();

    /**
     * @param int $entityId
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface
     */
    public function setEntityId($entityId);

    /**
     * @return string
     */
    public function getTitle(): string;

    /**
     * @param string $title
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface
     */
    public function setTitle(string $title): \Anjali\BannerSlider\Api\Data\SliderInterface;

    /**
     * @return int
     */
    public function getIsShowTitle(): int;

    /**
     * @param int $isShowTitle
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface
     */
    public function setIsShowTitle(int $isShowTitle): \Anjali\BannerSlider\Api\Data\SliderInterface;

    /**
     * @return int
     */
    public function getIsEnabled(): int;

    /**
     * @param int $isEnabled
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface
     */
    public function setIsEnabled(int $isEnabled): \Anjali\BannerSlider\Api\Data\SliderInterface;

    /**
     * @return string
     */
    public function getCreatedAt(): string;

    /**
     * @param string $createdAt
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface
     */
    public function setCreatedAt(string $createdAt): \Anjali\BannerSlider\Api\Data\SliderInterface;

    /**
     * @return string
     */
    public function getUpdatedAt(): string;

    /**
     * @param string $updatedAt
     * @return \Codilar\BannerSlider\Api\Data\SliderInterface
     */
    public function setUpdatedAt(string $updatedAt): \Anjali\BannerSlider\Api\Data\SliderInterface;

    /**
     * @return \Codilar\BannerSlider\Api\Data\BannerInterface[]
     */
    public function getBanners(): array;
}